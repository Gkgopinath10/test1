package com.umbrella.customerservice.repository;

import com.umbrella.customerservice.model.Customer;
import com.umbrella.customerservice.model.CustomerStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    Optional<Customer> findByEmail(String email);
    List<Customer> findByStatus(CustomerStatus status);
    List<Customer> findByCity(String city);
    List<Customer> findByCountry(String country);
    boolean existsByEmail(String email);
}
