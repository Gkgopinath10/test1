package com.umbrella.customerservice.service;

import com.umbrella.customerservice.dto.CustomerDTO;
import com.umbrella.customerservice.exception.CustomerNotFoundException;
import com.umbrella.customerservice.model.Customer;
import com.umbrella.customerservice.model.CustomerStatus;
import com.umbrella.customerservice.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerDTO registerCustomer(CustomerDTO dto) {
        if (customerRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("Customer with email already registered: " + dto.getEmail());
        }
        return mapToDTO(customerRepository.save(mapToEntity(dto)));
    }

    @Transactional(readOnly = true)
    public List<CustomerDTO> getAllCustomers() {
        return customerRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public CustomerDTO getCustomerById(Long id) {
        return mapToDTO(customerRepository.findById(id)
                .orElseThrow(() -> new CustomerNotFoundException("Customer not found with id: " + id)));
    }

    @Transactional(readOnly = true)
    public CustomerDTO getCustomerByEmail(String email) {
        return mapToDTO(customerRepository.findByEmail(email)
                .orElseThrow(() -> new CustomerNotFoundException("Customer not found with email: " + email)));
    }

    @Transactional(readOnly = true)
    public List<CustomerDTO> getByStatus(CustomerStatus status) {
        return customerRepository.findByStatus(status).stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public CustomerDTO updateCustomer(Long id, CustomerDTO dto) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new CustomerNotFoundException("Customer not found with id: " + id));
        if (!customer.getEmail().equals(dto.getEmail()) && customerRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("Email already in use: " + dto.getEmail());
        }
        customer.setFirstName(dto.getFirstName());
        customer.setLastName(dto.getLastName());
        customer.setEmail(dto.getEmail());
        customer.setPhone(dto.getPhone());
        customer.setAddress(dto.getAddress());
        customer.setCity(dto.getCity());
        customer.setCountry(dto.getCountry());
        customer.setDateOfBirth(dto.getDateOfBirth());
        if (dto.getStatus() != null) customer.setStatus(dto.getStatus());
        if (dto.getIsVerified() != null) customer.setIsVerified(dto.getIsVerified());
        return mapToDTO(customerRepository.save(customer));
    }

    public CustomerDTO verifyCustomer(Long id) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new CustomerNotFoundException("Customer not found with id: " + id));
        customer.setIsVerified(true);
        customer.setStatus(CustomerStatus.ACTIVE);
        return mapToDTO(customerRepository.save(customer));
    }

    public CustomerDTO updateStatus(Long id, CustomerStatus status) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new CustomerNotFoundException("Customer not found with id: " + id));
        customer.setStatus(status);
        return mapToDTO(customerRepository.save(customer));
    }

    public void deleteCustomer(Long id) {
        if (!customerRepository.existsById(id)) {
            throw new CustomerNotFoundException("Customer not found with id: " + id);
        }
        customerRepository.deleteById(id);
    }

    private Customer mapToEntity(CustomerDTO dto) {
        return Customer.builder()
                .firstName(dto.getFirstName())
                .lastName(dto.getLastName())
                .email(dto.getEmail())
                .phone(dto.getPhone())
                .address(dto.getAddress())
                .city(dto.getCity())
                .country(dto.getCountry())
                .dateOfBirth(dto.getDateOfBirth())
                .status(dto.getStatus() != null ? dto.getStatus() : CustomerStatus.PENDING)
                .isVerified(dto.getIsVerified() != null ? dto.getIsVerified() : Boolean.FALSE)
                .build();
    }

    private CustomerDTO mapToDTO(Customer c) {
        return CustomerDTO.builder()
                .id(c.getId())
                .firstName(c.getFirstName())
                .lastName(c.getLastName())
                .email(c.getEmail())
                .phone(c.getPhone())
                .address(c.getAddress())
                .city(c.getCity())
                .country(c.getCountry())
                .dateOfBirth(c.getDateOfBirth())
                .status(c.getStatus())
                .isVerified(c.getIsVerified())
                .createdAt(c.getCreatedAt())
                .updatedAt(c.getUpdatedAt())
                .build();
    }
}
