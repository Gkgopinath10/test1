package com.umbrella.customerservice.model;

public enum CustomerStatus {
    ACTIVE, INACTIVE, SUSPENDED, PENDING
}
