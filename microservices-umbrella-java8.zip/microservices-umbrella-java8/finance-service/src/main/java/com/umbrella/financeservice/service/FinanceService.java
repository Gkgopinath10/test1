package com.umbrella.financeservice.service;

import com.umbrella.financeservice.dto.TransactionDTO;
import com.umbrella.financeservice.exception.TransactionNotFoundException;
import com.umbrella.financeservice.model.Transaction;
import com.umbrella.financeservice.model.TransactionStatus;
import com.umbrella.financeservice.repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class FinanceService {

    private final TransactionRepository transactionRepository;

    public TransactionDTO createTransaction(TransactionDTO dto) {
        if (transactionRepository.existsByReferenceNumber(dto.getReferenceNumber())) {
            throw new IllegalArgumentException("Reference number already exists: " + dto.getReferenceNumber());
        }
        return mapToDTO(transactionRepository.save(mapToEntity(dto)));
    }

    @Transactional(readOnly = true)
    public List<TransactionDTO> getAllTransactions() {
        return transactionRepository.findAll().stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public TransactionDTO getTransactionById(Long id) {
        return mapToDTO(transactionRepository.findById(id)
                .orElseThrow(() -> new TransactionNotFoundException("Transaction not found with id: " + id)));
    }

    @Transactional(readOnly = true)
    public TransactionDTO getByReferenceNumber(String ref) {
        return mapToDTO(transactionRepository.findByReferenceNumber(ref)
                .orElseThrow(() -> new TransactionNotFoundException("Transaction not found with reference: " + ref)));
    }

    @Transactional(readOnly = true)
    public List<TransactionDTO> getByCustomerId(Long customerId) {
        return transactionRepository.findByCustomerId(customerId).stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<TransactionDTO> getByStatus(TransactionStatus status) {
        return transactionRepository.findByStatus(status).stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public TransactionDTO updateTransaction(Long id, TransactionDTO dto) {
        Transaction txn = transactionRepository.findById(id)
                .orElseThrow(() -> new TransactionNotFoundException("Transaction not found with id: " + id));
        if (!txn.getReferenceNumber().equals(dto.getReferenceNumber())
                && transactionRepository.existsByReferenceNumber(dto.getReferenceNumber())) {
            throw new IllegalArgumentException("Reference number already in use");
        }
        txn.setReferenceNumber(dto.getReferenceNumber());
        txn.setAmount(dto.getAmount());
        txn.setTransactionType(dto.getTransactionType());
        txn.setAccountNumber(dto.getAccountNumber());
        txn.setDescription(dto.getDescription());
        txn.setCurrency(dto.getCurrency());
        txn.setCustomerId(dto.getCustomerId());
        if (dto.getStatus() != null) txn.setStatus(dto.getStatus());
        return mapToDTO(transactionRepository.save(txn));
    }

    public TransactionDTO updateStatus(Long id, TransactionStatus status) {
        Transaction txn = transactionRepository.findById(id)
                .orElseThrow(() -> new TransactionNotFoundException("Transaction not found with id: " + id));
        txn.setStatus(status);
        return mapToDTO(transactionRepository.save(txn));
    }

    public void deleteTransaction(Long id) {
        if (!transactionRepository.existsById(id)) {
            throw new TransactionNotFoundException("Transaction not found with id: " + id);
        }
        transactionRepository.deleteById(id);
    }

    private Transaction mapToEntity(TransactionDTO dto) {
        return Transaction.builder()
                .referenceNumber(dto.getReferenceNumber())
                .amount(dto.getAmount())
                .transactionType(dto.getTransactionType())
                .status(dto.getStatus() != null ? dto.getStatus() : TransactionStatus.PENDING)
                .accountNumber(dto.getAccountNumber())
                .description(dto.getDescription())
                .currency(dto.getCurrency())
                .customerId(dto.getCustomerId())
                .build();
    }

    private TransactionDTO mapToDTO(Transaction t) {
        return TransactionDTO.builder()
                .id(t.getId())
                .referenceNumber(t.getReferenceNumber())
                .amount(t.getAmount())
                .transactionType(t.getTransactionType())
                .status(t.getStatus())
                .accountNumber(t.getAccountNumber())
                .description(t.getDescription())
                .currency(t.getCurrency())
                .customerId(t.getCustomerId())
                .createdAt(t.getCreatedAt())
                .updatedAt(t.getUpdatedAt())
                .build();
    }
}
