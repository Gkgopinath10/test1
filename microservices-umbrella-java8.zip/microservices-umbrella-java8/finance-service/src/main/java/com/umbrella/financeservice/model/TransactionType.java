package com.umbrella.financeservice.model;

public enum TransactionType {
    CREDIT, DEBIT, TRANSFER, REFUND, PAYMENT
}
