package com.umbrella.financeservice.controller;

import com.umbrella.financeservice.dto.TransactionDTO;
import com.umbrella.financeservice.model.TransactionStatus;
import com.umbrella.financeservice.service.FinanceService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/transactions")
@RequiredArgsConstructor
public class FinanceController {

    private final FinanceService financeService;

    @PostMapping
    public ResponseEntity<TransactionDTO> createTransaction(@Valid @RequestBody TransactionDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(financeService.createTransaction(dto));
    }

    @GetMapping
    public ResponseEntity<List<TransactionDTO>> getAllTransactions() {
        return ResponseEntity.ok(financeService.getAllTransactions());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TransactionDTO> getById(@PathVariable Long id) {
        return ResponseEntity.ok(financeService.getTransactionById(id));
    }

    @GetMapping("/reference/{ref}")
    public ResponseEntity<TransactionDTO> getByReference(@PathVariable String ref) {
        return ResponseEntity.ok(financeService.getByReferenceNumber(ref));
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<TransactionDTO>> getByCustomer(@PathVariable Long customerId) {
        return ResponseEntity.ok(financeService.getByCustomerId(customerId));
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<TransactionDTO>> getByStatus(@PathVariable TransactionStatus status) {
        return ResponseEntity.ok(financeService.getByStatus(status));
    }

    @PutMapping("/{id}")
    public ResponseEntity<TransactionDTO> updateTransaction(@PathVariable Long id, @Valid @RequestBody TransactionDTO dto) {
        return ResponseEntity.ok(financeService.updateTransaction(id, dto));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<TransactionDTO> updateStatus(@PathVariable Long id, @RequestParam TransactionStatus status) {
        return ResponseEntity.ok(financeService.updateStatus(id, status));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTransaction(@PathVariable Long id) {
        financeService.deleteTransaction(id);
        return ResponseEntity.noContent().build();
    }
}
