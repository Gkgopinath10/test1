package com.umbrella.financeservice.repository;

import com.umbrella.financeservice.model.Transaction;
import com.umbrella.financeservice.model.TransactionStatus;
import com.umbrella.financeservice.model.TransactionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    Optional<Transaction> findByReferenceNumber(String referenceNumber);
    List<Transaction> findByCustomerId(Long customerId);
    List<Transaction> findByStatus(TransactionStatus status);
    List<Transaction> findByTransactionType(TransactionType type);
    List<Transaction> findByAccountNumber(String accountNumber);
    boolean existsByReferenceNumber(String referenceNumber);
}
