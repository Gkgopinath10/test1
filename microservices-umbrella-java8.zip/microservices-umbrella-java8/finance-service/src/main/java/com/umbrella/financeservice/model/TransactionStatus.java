package com.umbrella.financeservice.model;

public enum TransactionStatus {
    PENDING, COMPLETED, FAILED, CANCELLED, PROCESSING
}
