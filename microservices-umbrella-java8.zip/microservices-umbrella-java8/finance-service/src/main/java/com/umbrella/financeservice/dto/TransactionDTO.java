package com.umbrella.financeservice.dto;

import com.umbrella.financeservice.model.TransactionStatus;
import com.umbrella.financeservice.model.TransactionType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransactionDTO {

    private Long id;

    @NotBlank(message = "Reference number is required")
    private String referenceNumber;

    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01")
    private BigDecimal amount;

    @NotNull(message = "Transaction type is required")
    private TransactionType transactionType;

    private TransactionStatus status;

    @NotBlank(message = "Account number is required")
    private String accountNumber;

    private String description;
    private String currency;
    private Long customerId;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
