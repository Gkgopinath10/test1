package com.simple.finance;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class FinanceService {

    private final FinanceRepository financeRepository;
    private final CustomerClient customerClient;
    private final ProductClient productClient;

    public Finance create(Finance finance) {

        // Step 1: Validate customer via customer-service
        if (finance.getCustomerId() != null) {
            try {
                log.info("Calling customer-service for customerId: {}", finance.getCustomerId());
                CustomerDTO customer = customerClient.getCustomerById(finance.getCustomerId());

                if (!"ACTIVE".equalsIgnoreCase(customer.getStatus())) {
                    throw new RuntimeException("Customer is not ACTIVE. Status: " + customer.getStatus());
                }

                finance.setCustomerName(customer.getName());
                log.info("Customer validated: {}", customer.getName());

            } catch (FeignException.NotFound e) {
                throw new RuntimeException("Customer not found with id: " + finance.getCustomerId());
            } catch (FeignException e) {
                throw new RuntimeException("Customer service unavailable");
            }
        }

        // Step 2: Validate product via product-service
        if (finance.getProductId() != null) {
            try {
                log.info("Calling product-service for productId: {}", finance.getProductId());
                ProductDTO product = productClient.getProductById(finance.getProductId());

                if (product.getQuantity() <= 0) {
                    throw new RuntimeException("Product out of stock: " + product.getName());
                }

                finance.setProductName(product.getName());
                log.info("Product validated: {}", product.getName());

            } catch (FeignException.NotFound e) {
                throw new RuntimeException("Product not found with id: " + finance.getProductId());
            } catch (FeignException e) {
                throw new RuntimeException("Product service unavailable");
            }
        }

        // Step 3: Save finance record
        return financeRepository.save(finance);
    }

    public List<Finance> getAll() {
        return financeRepository.findAll();
    }

    public Finance getById(Long id) {
        return financeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Finance record not found: " + id));
    }

    public List<Finance> getByCustomerId(Long customerId) {
        return financeRepository.findByCustomerId(customerId);
    }

    public List<Finance> getByProductId(Long productId) {
        return financeRepository.findByProductId(productId);
    }

    public Finance update(Long id, Finance updated) {
        Finance existing = getById(id);
        existing.setAmount(updated.getAmount());
        existing.setType(updated.getType());
        existing.setCustomerId(updated.getCustomerId());
        existing.setProductId(updated.getProductId());
        return financeRepository.save(existing);
    }

    public void delete(Long id) {
        if (!financeRepository.existsById(id)) {
            throw new RuntimeException("Finance record not found: " + id);
        }
        financeRepository.deleteById(id);
    }
}
