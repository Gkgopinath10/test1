package com.umbrella.financeservice;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FinanceRepository extends JpaRepository<Finance, Long> {
    List<Finance> findByCustomerId(Long customerId);
    List<Finance> findByProductId(Long productId);
}
