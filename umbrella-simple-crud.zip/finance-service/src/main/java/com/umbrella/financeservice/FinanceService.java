package com.umbrella.financeservice;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class FinanceService {

    private final FinanceRepository financeRepository;
    private final CustomerClient customerClient;
    private final ProductClient productClient;

    public Finance create(Finance finance) {

        // Validate customer via customer-service
        if (finance.getCustomerId() != null) {
            try {
                log.info("Validating customerId: {}", finance.getCustomerId());
                CustomerDTO customer = customerClient.getById(finance.getCustomerId());
                if (!"ACTIVE".equalsIgnoreCase(customer.getStatus())) {
                    throw new RuntimeException("Customer is not ACTIVE. Current status: " + customer.getStatus());
                }
                finance.setCustomerName(customer.getName());
            } catch (FeignException.NotFound e) {
                throw new RuntimeException("Customer not found: " + finance.getCustomerId());
            } catch (FeignException e) {
                throw new RuntimeException("Customer service error: " + e.getMessage());
            }
        }

        // Validate product via product-service
        if (finance.getProductId() != null) {
            try {
                log.info("Validating productId: {}", finance.getProductId());
                ProductDTO product = productClient.getById(finance.getProductId());
                if (product.getQuantity() <= 0) {
                    throw new RuntimeException("Product out of stock: " + product.getName());
                }
                finance.setProductName(product.getName());
            } catch (FeignException.NotFound e) {
                throw new RuntimeException("Product not found: " + finance.getProductId());
            } catch (FeignException e) {
                throw new RuntimeException("Product service error: " + e.getMessage());
            }
        }

        return financeRepository.save(finance);
    }

    public List<Finance> getAll() {
        return financeRepository.findAll();
    }

    public Finance getById(Long id) {
        return financeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Finance record not found: " + id));
    }

    public List<Finance> getByCustomerId(Long customerId) {
        return financeRepository.findByCustomerId(customerId);
    }

    public List<Finance> getByProductId(Long productId) {
        return financeRepository.findByProductId(productId);
    }

    public Finance update(Long id, Finance updated) {
        Finance existing = getById(id);
        existing.setAmount(updated.getAmount());
        existing.setType(updated.getType());
        existing.setCustomerId(updated.getCustomerId());
        existing.setProductId(updated.getProductId());
        existing.setCustomerName(updated.getCustomerName());
        existing.setProductName(updated.getProductName());
        return financeRepository.save(existing);
    }

    public void delete(Long id) {
        if (!financeRepository.existsById(id)) {
            throw new RuntimeException("Finance record not found: " + id);
        }
        financeRepository.deleteById(id);
    }
}
