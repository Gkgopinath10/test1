package com.umbrella.financeservice;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/finance")
@RequiredArgsConstructor
public class FinanceController {

    private final FinanceService financeService;

    @PostMapping
    public ResponseEntity<Finance> create(@RequestBody Finance finance) {
        return ResponseEntity.status(HttpStatus.CREATED).body(financeService.create(finance));
    }

    @GetMapping
    public ResponseEntity<List<Finance>> getAll() {
        return ResponseEntity.ok(financeService.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Finance> getById(@PathVariable Long id) {
        return ResponseEntity.ok(financeService.getById(id));
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<Finance>> getByCustomer(@PathVariable Long customerId) {
        return ResponseEntity.ok(financeService.getByCustomerId(customerId));
    }

    @GetMapping("/product/{productId}")
    public ResponseEntity<List<Finance>> getByProduct(@PathVariable Long productId) {
        return ResponseEntity.ok(financeService.getByProductId(productId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Finance> update(@PathVariable Long id, @RequestBody Finance finance) {
        return ResponseEntity.ok(financeService.update(id, finance));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        financeService.delete(id);
        return ResponseEntity.ok("Finance record deleted successfully");
    }
}
