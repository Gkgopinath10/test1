package com.umbrella.financeservice;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "finance")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Finance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private BigDecimal amount;

    private String type;          // CREDIT / DEBIT

    private Long customerId;

    private Long productId;

    private String customerName;  // auto-filled from customer-service

    private String productName;   // auto-filled from product-service
}
